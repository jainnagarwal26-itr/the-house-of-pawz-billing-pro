THE HOUSE OF PAWZ - JULY 34-58 MYSQL MIGRATION
FINAL CORRECTED VERSION

Target scope ONLY:
HOP/26-27/000034 through HOP/26-27/000058 (25 invoices)
Historical HOP/26-27/000001 through HOP/26-27/000033 are protected.

IMPORTANT
- Do NOT run live migration immediately after upload.
- First run the mandatory --dry-run.
- Dry-run performs source validation plus read-only compatibility checks against the actual MySQL schema.
- No INSERT/UPDATE/DELETE is executed in dry-run mode.
- Live migration uses one MySQL transaction and rolls back on any exception or verification failure.

KNOWN FAILURES FIXED FROM THE PREVIOUS RUNS
1. Required MySQL customers.id with no default:
   - Source Supabase id is never copied into target primary key.
   - Auto-increment ids are omitted.
   - Required UUID-compatible target ids are generated safely.
   - Unsupported required numeric ids fail before any live INSERT.

2. Invalid datetime values:
   - DATE columns are normalized to YYYY-MM-DD.
   - DATETIME/TIMESTAMP columns are normalized to YYYY-MM-DD HH:MM:SS.
   - ISO-8601 values, date-only values and DD/MM/YYYY values are handled.
   - Invalid dates abort before live insertion.

3. Exact money handling:
   - No float arithmetic.
   - No BCMath dependency.
   - Decimal string arithmetic/comparison only.

4. Invoice relationship mapping:
   - Supabase internal_invoice_id is mapped to the actual target invoice reference.
   - invoice_items and payments use the target mapping, not the raw source reference.

5. Customer/Pet foreign-key mapping:
   - Existing target business IDs are reused when present.
   - New profiles receive target-generated primary IDs where required.

6. Verification:
   - Per-invoice monetary checks.
   - Per-item monetary checks.
   - Per-payment amount checks.
   - Invoice/item/payment counts.
   - Historical 000001-000033 baseline protection.
   - Post-commit audit checks grand total, paid total and balance total.

cPanel DRY-RUN COMMAND
/usr/local/bin/php /home/jainnaga/public_html/the-house-of-pawz/cron/migrate_supabase_july_34_58.php --dry-run

cPanel LIVE COMMAND - ONLY AFTER DRY-RUN PASSES
/usr/local/bin/php /home/jainnaga/public_html/the-house-of-pawz/cron/migrate_supabase_july_34_58.php

After the one-time Cron executes, DELETE THE CRON JOB immediately.
Then inspect:
/home/jainnaga/the-house-of-pawz/logs/migration_july_34_58.log

Do not delete old backup PHP files until the migration is fully verified.
